<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        <?php echo e(__('Report - Annual GAD Plan and Budget '.$year)); ?>

     <?php $__env->endSlot(); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Report / Annual GAD Plan and Budget')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="max-w-8xl mx-auto sm:px-6 lg:px-8 space-y-6">
            <div class="p-4 bg-white shadow sm:rounded-lg">
                <section>
                    <header>
                        <div class="flex w-32 mx-auto float-end">
                            <label class="">YEAR&nbsp;</label>
                            <select onchange="window.location.href='?year='+this.value" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                <option value="">-YEAR-</option>
                                <?php for($i=date('Y'); $i >= 2018; $i--): ?>
                                <option value="<?php echo e($i); ?>" <?php echo e(($i==$year) ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <h2 class="text-lg font-medium text-gray-900">
                            <?php echo e(__('ANNUAL GENDER AND DEVELOPMENT (GAD) PLAN AND BUDGET '.$year)); ?>

                        </h2>
                    </header>
                    <div class="min-w-full w-full py-6 overflow-x-scroll">
                        <table class="table-auto min-w-full w-full border-collapse border border-slate-400 divide-y divide-gray-200">
                            <thead>
                            <tr>
                                <th class="border border-slate-300 px-2 py-2 bg-gray-50">
                                    <span class="text-sm font-medium leading-4 tracking-wider text-left text-gray-700 uppercase">Gender Issue/GAD Mandate</span>
                                </th>
                                <th class="border border-slate-300 px-2 py-2 bg-gray-50">
                                    <span class="text-sm font-medium leading-4 tracking-wider text-left text-gray-700 uppercase">Cause of Gender Issue</span>
                                </th>
                                <th class="border border-slate-300 px-2 py-2 bg-gray-50">
                                    <span class="text-sm font-medium leading-4 tracking-wider text-left text-gray-700 uppercase">GAD Result Statement/ GAD Objective</span>
                                </th>
                                <th class="border border-slate-300 px-2 py-2 bg-gray-50">
                                    <span class="text-sm font-medium leading-4 tracking-wider text-left text-gray-700 uppercase">Relevant Organization MFO/PAP or PPA</span>
                                </th>
                                <th class="border border-slate-300 px-2 py-2 bg-gray-50">
                                    <span class="text-sm font-medium leading-4 tracking-wider text-left text-gray-700 uppercase">GAD Activity</span>
                                </th>
                                <th class="border border-slate-300 px-2 py-2 bg-gray-50">
                                    <span class="text-sm font-medium leading-4 tracking-wider text-left text-gray-700 uppercase">Performance Indicators /Targets</span>
                                </th>
                                <th class="border border-slate-300 px-2 py-2 bg-gray-50">
                                    <span class="text-sm font-medium leading-4 tracking-wider text-left text-gray-700 uppercase">Actual Results/ Outputs and Outcomes </span>
                                </th>
                                <th class="border border-slate-300 px-2 py-2 bg-gray-50">
                                    <span class="text-sm font-medium leading-4 tracking-wider text-left text-gray-700 uppercase">GAD Budget</span>
                                </th>
                                <th class="border border-slate-300 px-2 py-2 bg-gray-50">
                                    <span class="text-sm font-medium leading-4 tracking-wider text-left text-gray-700 uppercase">Actual Cost / Cost Expenditure</span>
                                </th>
                                <th class="border border-slate-300 px-2 py-2 bg-gray-50">
                                    <span class="text-sm font-medium leading-4 tracking-wider text-left text-gray-700 uppercase">Remarks</span>
                                </th>
                            </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="10" class="px-2 py-2 text-md bg-orange-100">
                                        CLIENT-FOCUSED ACTIVITIES
                                    </td>
                                </tr>
                                <?php $__currentLoopData = $goals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $goal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($goal->focus=='client'): ?>
                                <tr>
                                    <td colspan="10" class="px-2 py-2 text-md bg-blue-100">
                                        GAD Goal <?php echo e($goal->goal_no); ?>: <?php echo e($goal->gad_goal); ?>

                                    </td>
                                </tr>
                                <?php endif; ?>

                                <?php $__empty_1 = true; $__currentLoopData = $planbudgets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $planbudget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php if($goal->focus=='client' && $goal->goal_id == $planbudget->goal_id && $planbudget->focus=='client'): ?>
                                <?php
                                    $ga_count_c = count($planbudget->gad_activities);
                                ?>
                                <tr class="align-text-top">
                                    <td rowspan="<?php echo e($ga_count_c); ?>" class="border border-slate-300 px-2 py-2 text-sm leading-5 text-gray-900 whitespace-no-wrap">
                                        <?php echo e($planbudget->gender_issue_mandate); ?>

                                    </td>
                                    <td rowspan="<?php echo e($ga_count_c); ?>" class="border border-slate-300 px-2 py-2 text-sm leading-5 text-gray-900 whitespace-no-wrap">
                                        <?php echo e($planbudget->cause_gender_issue); ?>

                                    </td>
                                    <td rowspan="<?php echo e($ga_count_c); ?>" class="border border-slate-300 px-2 py-2 text-sm leading-5 text-gray-900 whitespace-no-wrap">
                                        <?php echo e($planbudget->gad_objective); ?>

                                    </td>
                                    <td rowspan="<?php echo e($ga_count_c); ?>" class="border border-slate-300 px-2 py-2 text-sm leading-5 text-gray-900 whitespace-no-wrap">
                                        <?php echo e($planbudget->relevant_org); ?>

                                    </td>                                    
                                </tr>
                                
                                <?php if(!empty($ga_count_c)): ?>
                                <?php $__currentLoopData = $planbudget->gad_activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $gad_act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $key ?>
                                <tr>
                                    <td class="border border-slate-300 px-2 py-2 text-sm leading-5 text-gray-900 whitespace-no-wrap">
                                        <?php echo $gad_act->main_activity; ?>

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                
                                <?php endif; ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td colspan="10" class="px-2 py-2 text-md bg-orange-100">
                                        ORGANIZATIONAL FOCUSED
                                    </td>
                                </tr>
                                <?php $__currentLoopData = $goals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $goal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($goal->focus=='organizational'): ?>
                                <tr>
                                    <td colspan="10" class="px-2 py-2 text-md bg-blue-100">
                                        GAD Goal <?php echo e($goal->goal_no); ?>: <?php echo e($goal->gad_goal); ?>

                                    </td>
                                </tr>
                                <?php endif; ?>

                                <?php $__empty_1 = true; $__currentLoopData = $planbudgets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $planbudget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php if($goal->focus=='organizational' && $goal->goal_id == $planbudget->goal_id && $planbudget->focus=='organizational'): ?>
                                <?php
                                    $ga_count_o = count($planbudget->gad_activities);
                                ?>
                                <tr class="align-text-top">
                                    <td rowspan="<?php echo e($ga_count_o); ?>" class="border border-slate-300 px-2 py-2 text-sm leading-5 text-gray-900 whitespace-no-wrap">
                                        <?php echo e($planbudget->gender_issue_mandate); ?>

                                    </td>
                                    <td rowspan="<?php echo e($ga_count_o); ?>" class="border border-slate-300 px-2 py-2 text-sm leading-5 text-gray-900 whitespace-no-wrap">
                                        <?php echo e($planbudget->cause_gender_issue); ?>

                                    </td>
                                    <td rowspan="<?php echo e($ga_count_o); ?>" class="border border-slate-300 px-2 py-2 text-sm leading-5 text-gray-900 whitespace-no-wrap">
                                        <?php echo e($planbudget->gad_objective); ?>

                                    </td>
                                    <td rowspan="<?php echo e($ga_count_o); ?>" class="border border-slate-300 px-2 py-2 text-sm leading-5 text-gray-900 whitespace-no-wrap">
                                        <?php echo e($planbudget->relevant_org); ?>

                                    </td>
                                    <?php
                                        $act_details_o = 0;
                                        $activity_details_o = [];
                                    ?>
                                    <?php $__currentLoopData = $planbudget->gad_activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gadacty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $act_details_o = count($gadacty->activity_details);
                                        $activity_details_o = $gadacty->activity_details;
                                    ?>
                                    <td class="border border-slate-300 px-2 py-2 text-sm leading-5 text-gray-900 whitespace-no-wrap">
                                        <?php echo e($gadacty->main_activity); ?>

                                    </td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($act_details_o == 1): ?>
                                    <?php $__currentLoopData = $activity_details_o; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity_detail_o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td class="border border-slate-300 px-2 py-2 text-sm leading-5 text-gray-900 whitespace-no-wrap">
                                        <?php echo $activity_detail_o->targets; ?>

                                    </td>
                                    <td class="border border-slate-300 px-2 py-2 text-sm leading-5 text-gray-900 whitespace-no-wrap">
                                        <?php echo $activity_detail_o->actual_result; ?>

                                    </td>
                                    <td class="border border-slate-300 px-2 py-2 text-sm leading-5 text-gray-900 whitespace-no-wrap">
                                        <?php echo e($activity_detail_o->gad_budget); ?>

                                    </td>
                                    <td class="border border-slate-300 px-2 py-2 text-sm leading-5 text-gray-900 whitespace-no-wrap">
                                        <?php echo e($activity_detail_o->actual_cost); ?>

                                    </td>
                                    <td class="border border-slate-300 px-2 py-2 text-sm leading-5 text-gray-900 whitespace-no-wrap">
                                        <?php echo $activity_detail_o->remarks; ?>

                                    </td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tr>
                                <?php endif; ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </section>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Apache24\htdocs\gendersphere\resources\views/pages/reports/gadplanbudgets.blade.php ENDPATH**/ ?>